#!/usr/bin/php -q
<?php
require("../src/timezone.php");
print get_time_zone("US", "WV");

